"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Search, Save, X, ImageIcon } from "lucide-react"
import Image from "next/image"

interface MovieData {
  title: string
  poster: string
  genre: string
  year: number
  duration: number
  rating: number
  price: number
  description: string
  director: string
  cast: string[]
  releaseDate: string
}

export default function AddFilmPage() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [movieData, setMovieData] = useState<MovieData | null>(null)
  const [loading, setLoading] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [posterPreview, setPosterPreview] = useState<string>("")

  useEffect(() => {
    // Check if user is authenticated staff
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/")
      return
    }
    setIsAuthenticated(true)
  }, [router])

  const searchMovie = async () => {
    if (!searchTerm.trim()) return

    setLoading(true)
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/")
        return
      }

      const response = await fetch(`/api/search-movie?title=${encodeURIComponent(searchTerm)}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const data = await response.json()
      setMovieData(data)
      setPosterPreview(data.poster || "")
    } catch (error) {
      console.error("Search error:", error)
      alert("Failed to search for movie. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof MovieData, value: any) => {
    if (!movieData) return

    setMovieData({
      ...movieData,
      [field]: value,
    })

    // Update poster preview when poster URL changes
    if (field === "poster") {
      setPosterPreview(value)
    }
  }

  const handlePosterUrlChange = (url: string) => {
    handleInputChange("poster", url)
    setPosterPreview(url)
  }

  const handleCastChange = (index: number, value: string) => {
    if (!movieData) return

    const newCast = [...movieData.cast]
    newCast[index] = value
    setMovieData({
      ...movieData,
      cast: newCast,
    })
  }

  const addCastMember = () => {
    if (!movieData) return

    setMovieData({
      ...movieData,
      cast: [...movieData.cast, ""],
    })
  }

  const removeCastMember = (index: number) => {
    if (!movieData) return

    const newCast = movieData.cast.filter((_, i) => i !== index)
    setMovieData({
      ...movieData,
      cast: newCast,
    })
  }

  const saveMovie = async () => {
    if (!movieData) return

    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/")
        return
      }

      const response = await fetch("/api/movies", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(movieData),
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const result = await response.json()
      alert("Movie saved successfully!")
      router.push("/")
    } catch (error) {
      console.error("Save error:", error)
      alert("Error saving movie. Please try again.")
    }
  }

  const cancelEdit = () => {
    setMovieData(null)
    setSearchTerm("")
    setPosterPreview("")
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <Button onClick={() => router.push("/")} variant="outline" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 max-w-6xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl text-white">Add New Film</CardTitle>
            <CardDescription className="text-gray-300">
              Search for a movie and edit its details before adding to the database
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Search Section */}
            <div className="space-y-4">
              <Label htmlFor="search" className="text-white">
                Search Movie
              </Label>
              <div className="flex space-x-2">
                <Input
                  id="search"
                  placeholder="Enter movie title to search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                  onKeyPress={(e) => e.key === "Enter" && searchMovie()}
                />
                <Button onClick={searchMovie} disabled={loading}>
                  <Search className="mr-2 h-4 w-4" />
                  {loading ? "Searching..." : "Search"}
                </Button>
              </div>
            </div>

            {/* Movie Edit Form */}
            {movieData && (
              <div className="space-y-6 border-t border-white/20 pt-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Poster Section */}
                  <div className="space-y-4">
                    <Label className="text-white">Movie Poster</Label>
                    <div className="space-y-4">
                      {/* Poster Preview */}
                      <div className="relative">
                        <div className="aspect-[2/3] w-full max-w-sm mx-auto bg-gray-800 rounded-lg overflow-hidden border-2 border-white/20">
                          {posterPreview ? (
                            <Image
                              src={posterPreview || "/placeholder.svg"}
                              alt="Movie poster preview"
                              width={300}
                              height={450}
                              className="w-full h-full object-cover"
                              onError={() => setPosterPreview("")}
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-400">
                              <div className="text-center">
                                <ImageIcon className="h-16 w-16 mx-auto mb-2" />
                                <p>No poster image</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Poster URL Input */}
                      <div className="space-y-2">
                        <Label htmlFor="posterUrl" className="text-white">
                          Poster URL
                        </Label>
                        <Input
                          id="posterUrl"
                          placeholder="Enter poster image URL..."
                          value={movieData.poster}
                          onChange={(e) => handlePosterUrlChange(e.target.value)}
                          className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                        />
                      </div>

                      {/* Sample Poster URLs for Demo */}
                      <div className="space-y-2">
                        <Label className="text-white text-sm">Sample Poster URLs:</Label>
                        <div className="space-y-1">
                          {[
                            {
                              title: "The Matrix",
                              url: "https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg",
                            },
                            {
                              title: "Inception",
                              url: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg",
                            },
                          ].map((sample, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              onClick={() => handlePosterUrlChange(sample.url)}
                              className="text-xs h-8 w-full justify-start"
                            >
                              {sample.title}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Movie Details */}
                  <div className="lg:col-span-2 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="title" className="text-white">
                          Title (Read-only)
                        </Label>
                        <Input
                          id="title"
                          value={movieData.title}
                          readOnly
                          className="bg-gray-600/50 border-white/20 text-gray-300"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="genre" className="text-white">
                          Genre
                        </Label>
                        <Input
                          id="genre"
                          value={movieData.genre}
                          onChange={(e) => handleInputChange("genre", e.target.value)}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="year" className="text-white">
                          Year
                        </Label>
                        <Input
                          id="year"
                          type="number"
                          value={movieData.year}
                          onChange={(e) => handleInputChange("year", Number.parseInt(e.target.value))}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="duration" className="text-white">
                          Duration (minutes)
                        </Label>
                        <Input
                          id="duration"
                          type="number"
                          value={movieData.duration}
                          onChange={(e) => handleInputChange("duration", Number.parseInt(e.target.value))}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="rating" className="text-white">
                          Rating
                        </Label>
                        <Input
                          id="rating"
                          type="number"
                          step="0.1"
                          min="0"
                          max="10"
                          value={movieData.rating}
                          onChange={(e) => handleInputChange("rating", Number.parseFloat(e.target.value))}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="price" className="text-white">
                          Price (ETH)
                        </Label>
                        <Input
                          id="price"
                          type="number"
                          step="0.001"
                          min="0"
                          value={movieData.price}
                          onChange={(e) => handleInputChange("price", Number.parseFloat(e.target.value))}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="e.g., 0.049"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="director" className="text-white">
                          Director
                        </Label>
                        <Input
                          id="director"
                          value={movieData.director}
                          onChange={(e) => handleInputChange("director", e.target.value)}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="releaseDate" className="text-white">
                          Release Date
                        </Label>
                        <Input
                          id="releaseDate"
                          type="date"
                          value={movieData.releaseDate}
                          onChange={(e) => handleInputChange("releaseDate", e.target.value)}
                          className="bg-white/10 border-white/20 text-white"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description" className="text-white">
                        Description
                      </Label>
                      <Textarea
                        id="description"
                        value={movieData.description}
                        onChange={(e) => handleInputChange("description", e.target.value)}
                        className="bg-white/10 border-white/20 text-white min-h-[100px]"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label className="text-white">Cast</Label>
                        <Button onClick={addCastMember} variant="outline" size="sm">
                          Add Cast Member
                        </Button>
                      </div>
                      {movieData.cast.map((actor, index) => (
                        <div key={index} className="flex space-x-2">
                          <Input
                            value={actor}
                            onChange={(e) => handleCastChange(index, e.target.value)}
                            placeholder={`Actor ${index + 1}`}
                            className="bg-white/10 border-white/20 text-white"
                          />
                          <Button onClick={() => removeCastMember(index)} variant="outline" size="icon">
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>

                    <div className="flex space-x-4 pt-6">
                      <Button onClick={saveMovie} className="bg-green-600 hover:bg-green-700">
                        <Save className="mr-2 h-4 w-4" />
                        Save Movie
                      </Button>
                      <Button onClick={cancelEdit} variant="outline">
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
