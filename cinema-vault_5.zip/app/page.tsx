"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Film,
  Play,
  Wallet,
  User,
  Calendar,
  Clock,
  Search,
  Filter,
  AlertCircle,
  CheckCircle,
  Wifi,
  WifiOff,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface Movie {
  _id: string
  title: string
  poster: string
  genre: string
  year: number
  duration: number
  rating: number
  price: number
  description: string
  director: string
  cast: string[]
  releaseDate: string
}

interface ApiResponse {
  movies: Movie[]
  meta: {
    source: "api" | "mock" | "fallback"
    timestamp: string
    total: number
    error?: string
  }
}

export default function HomePage() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [loginOpen, setLoginOpen] = useState(false)
  const [walletConnected, setWalletConnected] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedMonth, setSelectedMonth] = useState("")
  const [currentDateTime, setCurrentDateTime] = useState(new Date())
  const [dataSource, setDataSource] = useState<"api" | "mock" | "fallback">("mock")
  const router = useRouter()

  const moviesPerPage = 8

  // Check for existing user session on load
  useEffect(() => {
    const token = localStorage.getItem("token")
    const storedUser = localStorage.getItem("user")

    if (token && storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (e) {
        console.error("Error parsing stored user:", e)
        localStorage.removeItem("token")
        localStorage.removeItem("user")
      }
    }

    fetchMovies()

    const timer = setInterval(() => {
      setCurrentDateTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    filterMovies()
  }, [movies, searchTerm, selectedMonth])

  const fetchMovies = async () => {
    try {
      setLoading(true)

      const response = await fetch("/api/movies")

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const data: ApiResponse = await response.json()

      // Handle both old format (direct array) and new format (with meta)
      if (Array.isArray(data)) {
        // Old format - direct array
        setMovies(data)
        setDataSource("mock")
      } else {
        // New format - with metadata
        setMovies(data.movies || [])
        setDataSource(data.meta?.source || "mock")
      }

      setFilteredMovies(data.movies || data)
    } catch (error) {
      console.error("Error fetching movies:", error)
      setMovies([])
      setDataSource("fallback")
    } finally {
      setLoading(false)
    }
  }

  const filterMovies = () => {
    if (!movies.length) return

    let filtered = movies

    if (searchTerm) {
      filtered = filtered.filter(
        (movie) =>
          movie.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.genre.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedMonth) {
      filtered = filtered.filter((movie) => {
        const releaseMonth = new Date(movie.releaseDate).getMonth() + 1
        return releaseMonth.toString() === selectedMonth
      })
    }

    setFilteredMovies(filtered)
  }

  const handleLogin = async (credentials: any) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
      })

      if (!response.ok) {
        throw new Error(`Login failed: ${response.status}`)
      }

      const data = await response.json()

      if (data.token) {
        localStorage.setItem("token", data.token)
        localStorage.setItem("user", JSON.stringify(data.user))
        setUser(data.user)
        setLoginOpen(false)
      }
    } catch (error) {
      console.error("Login error:", error)
      alert("Login failed. Please check your credentials and try again.")
    }
  }

  const connectWallet = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })
        const address = accounts[0]

        setWalletConnected(true)

        // Create wallet user
        const walletUser = {
          type: "customer",
          wallet: true,
          address: address,
        }

        // Store wallet user info
        localStorage.setItem("token", "wallet-" + Date.now())
        localStorage.setItem("user", JSON.stringify(walletUser))
        setUser(walletUser)
        setLoginOpen(false)
      } catch (error) {
        console.error("Wallet connection error:", error)
        alert("Failed to connect wallet. Please try again.")
      }
    } else {
      alert("Please install MetaMask to connect your wallet")
    }
  }

  const handleRentMovie = async (movieId: string, price: number) => {
    if (!user) {
      setLoginOpen(true)
      return
    }

    try {
      const token = localStorage.getItem("token")

      const response = await fetch("/api/rent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token || ""}`,
        },
        body: JSON.stringify({ movieId, price }),
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const result = await response.json()
      alert("Movie rented successfully! You can now watch it for 48 hours.")
    } catch (error) {
      console.error("Rental error:", error)
      alert("Failed to rent movie. Please try again.")
    }
  }

  const logout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    setUser(null)
    setWalletConnected(false)
  }

  const paginatedMovies = filteredMovies.slice((currentPage - 1) * moviesPerPage, currentPage * moviesPerPage)

  const totalPages = Math.ceil(filteredMovies.length / moviesPerPage)

  // Get status info based on data source
  const getStatusInfo = () => {
    switch (dataSource) {
      case "api":
        return {
          icon: <CheckCircle className="h-3 w-3 mr-1" />,
          text: "Live Mode - Connected to API",
          color: "text-green-400 border-green-400",
        }
      case "mock":
        return {
          icon: <Wifi className="h-3 w-3 mr-1" />,
          text: "Demo Mode - Using sample data",
          color: "text-yellow-400 border-yellow-400",
        }
      case "fallback":
        return {
          icon: <WifiOff className="h-3 w-3 mr-1" />,
          text: "Offline Mode - Limited functionality",
          color: "text-red-400 border-red-400",
        }
      default:
        return {
          icon: <AlertCircle className="h-3 w-3 mr-1" />,
          text: "Loading...",
          color: "text-gray-400 border-gray-400",
        }
    }
  }

  const statusInfo = getStatusInfo()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Film className="h-8 w-8 text-purple-400" />
              <h1 className="text-2xl font-bold text-white">CinemaVault</h1>
              <Badge variant="outline" className={statusInfo.color}>
                {statusInfo.icon}
                {dataSource === "api" ? "Live" : dataSource === "mock" ? "Demo" : "Offline"}
              </Badge>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-white text-sm">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4" />
                  <span>{currentDateTime.toLocaleDateString()}</span>
                  <Clock className="h-4 w-4 ml-2" />
                  <span>{currentDateTime.toLocaleTimeString()}</span>
                </div>
              </div>

              {user ? (
                <div className="flex items-center space-x-2">
                  <span className="text-white">Welcome, {user.type === "staff" ? "Staff" : "Customer"}</span>
                  {user.type === "staff" && (
                    <>
                      <Link href="/add-film">
                        <Button variant="outline" size="sm">
                          Add Film
                        </Button>
                      </Link>
                      <Link href="/profile">
                        <Button variant="outline" size="sm">
                          Profile
                        </Button>
                      </Link>
                      <Link href="/change-password">
                        <Button variant="outline" size="sm">
                          Change Password
                        </Button>
                      </Link>
                    </>
                  )}
                  <Button onClick={logout} variant="outline" size="sm">
                    Logout
                  </Button>
                </div>
              ) : (
                <Dialog open={loginOpen} onOpenChange={setLoginOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">Login</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Login to CinemaVault</DialogTitle>
                      <DialogDescription>Choose your login method</DialogDescription>
                    </DialogHeader>
                    <Tabs defaultValue="wallet">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="wallet">Wallet Login</TabsTrigger>
                        <TabsTrigger value="staff">Staff Login</TabsTrigger>
                      </TabsList>
                      <TabsContent value="wallet" className="space-y-4">
                        <Button onClick={connectWallet} className="w-full">
                          <Wallet className="mr-2 h-4 w-4" />
                          Connect Wallet
                        </Button>
                      </TabsContent>
                      <TabsContent value="staff" className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="username">Username</Label>
                          <Input id="username" placeholder="Enter staff username" defaultValue="s235776767" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="password">Password</Label>
                          <Input id="password" type="password" placeholder="Enter password" defaultValue="1234567890" />
                        </div>
                        <Button
                          onClick={() => handleLogin({ username: "s235776767", password: "1234567890", type: "staff" })}
                          className="w-full"
                        >
                          <User className="mr-2 h-4 w-4" />
                          Staff Login
                        </Button>
                      </TabsContent>
                    </Tabs>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Status Banner */}
      <div
        className={`${dataSource === "api" ? "bg-green-600/20 border-green-400/30" : dataSource === "mock" ? "bg-yellow-600/20 border-yellow-400/30" : "bg-red-600/20 border-red-400/30"} border-b`}
      >
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-center space-x-2 text-sm">
            <div
              className={`flex items-center ${dataSource === "api" ? "text-green-200" : dataSource === "mock" ? "text-yellow-200" : "text-red-200"}`}
            >
              {statusInfo.icon}
              <span>{statusInfo.text}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search movies by title or genre..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-white" />
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white"
              >
                <option value="">All Months</option>
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(0, i).toLocaleString("default", { month: "long" })}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Movie Grid */}
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-purple-400 mx-auto mb-4"></div>
              <p className="text-white">Loading movies...</p>
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {paginatedMovies.length > 0 ? (
                paginatedMovies.map((movie) => (
                  <Card
                    key={movie._id}
                    className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/20 transition-all duration-300"
                  >
                    <CardHeader className="p-0">
                      <div className="relative">
                        <Image
                          src={movie.poster || "/placeholder.svg?height=400&width=300"}
                          alt={movie.title}
                          width={300}
                          height={400}
                          className="w-full h-64 object-cover rounded-t-lg"
                          crossOrigin="anonymous"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement
                            target.src = "/placeholder.svg?height=400&width=300"
                          }}
                        />
                        <Badge className="absolute top-2 right-2 bg-purple-600">{movie.rating}/10</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <CardTitle className="text-white mb-2">{movie.title}</CardTitle>
                      <CardDescription className="text-gray-300 mb-4">
                        {movie.genre} • {movie.year} • {movie.duration}min
                      </CardDescription>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-purple-400">{movie.price} ETH</span>
                        <div className="space-x-2">
                          <Link href={`/movie/${movie._id}`}>
                            <Button variant="outline" size="sm">
                              Details
                            </Button>
                          </Link>
                          <Button
                            onClick={() => handleRentMovie(movie._id, movie.price)}
                            size="sm"
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            <Play className="mr-1 h-3 w-3" />
                            Rent
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <div className="text-white text-xl">No movies found matching your search criteria</div>
                  <Button
                    onClick={() => {
                      setSearchTerm("")
                      setSelectedMonth("")
                    }}
                    variant="outline"
                    className="mt-4"
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <Button
                    key={i + 1}
                    variant={currentPage === i + 1 ? "default" : "outline"}
                    onClick={() => setCurrentPage(i + 1)}
                  >
                    {i + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black/20 backdrop-blur-md border-t border-white/10 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Film className="h-6 w-6 text-purple-400" />
                <h3 className="text-lg font-bold text-white">CinemaVault</h3>
              </div>
              <p className="text-gray-300">Your premium destination for blockchain-powered movie rentals.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <a href="#" className="hover:text-purple-400">
                    Browse Movies
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-purple-400">
                    New Releases
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-purple-400">
                    Top Rated
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <a href="#" className="hover:text-purple-400">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-purple-400">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-purple-400">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <p className="text-gray-300">Built with Web3 technology for secure, decentralized movie streaming.</p>
            </div>
          </div>
          <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 CinemaVault. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
