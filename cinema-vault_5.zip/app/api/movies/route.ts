import { NextResponse } from "next/server"

// Mock movie data with updated prices in 0.0x ETH format
const mockMovies = [
  {
    _id: "1",
    title: "The Matrix",
    poster:
      "https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg",
    genre: "Sci-Fi",
    year: 1999,
    duration: 136,
    rating: 8.7,
    price: 0.049,
    description: "A computer programmer discovers reality is a simulation.",
    director: "The Wachowskis",
    cast: ["Keanu Reeves", "Laurence Fishburne"],
    releaseDate: "1999-03-31",
  },
  {
    _id: "2",
    title: "Inception",
    poster: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg",
    genre: "Thriller",
    year: 2010,
    duration: 148,
    rating: 8.8,
    price: 0.059,
    description: "A thief enters people's dreams to steal secrets.",
    director: "Christopher Nolan",
    cast: ["Leonardo DiCaprio", "Marion Cotillard"],
    releaseDate: "2010-07-16",
  },
  {
    _id: "3",
    title: "Interstellar",
    poster:
      "https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
    genre: "Sci-Fi",
    year: 2014,
    duration: 169,
    rating: 8.6,
    price: 0.069,
    description: "A team explores space to save humanity.",
    director: "Christopher Nolan",
    cast: ["Matthew McConaughey", "Anne Hathaway"],
    releaseDate: "2014-11-07",
  },
  {
    _id: "4",
    title: "The Dark Knight",
    poster: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_SX300.jpg",
    genre: "Action",
    year: 2008,
    duration: 152,
    rating: 9.0,
    price: 0.059,
    description: "Batman faces the Joker in Gotham City.",
    director: "Christopher Nolan",
    cast: ["Christian Bale", "Heath Ledger"],
    releaseDate: "2008-07-18",
  },
  {
    _id: "5",
    title: "Pulp Fiction",
    poster:
      "https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTUtNTBlZi00MTRlLWFjM2ItYzViMjE3YzI5MjljXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",
    genre: "Crime",
    year: 1994,
    duration: 154,
    rating: 8.9,
    price: 0.049,
    description: "The lives of two mob hitmen, a boxer, and others intertwine.",
    director: "Quentin Tarantino",
    cast: ["John Travolta", "Samuel L. Jackson"],
    releaseDate: "1994-10-14",
  },
  {
    _id: "6",
    title: "The Godfather",
    poster:
      "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",
    genre: "Crime",
    year: 1972,
    duration: 175,
    rating: 9.2,
    price: 0.069,
    description: "The aging patriarch of an organized crime dynasty transfers control to his son.",
    director: "Francis Ford Coppola",
    cast: ["Marlon Brando", "Al Pacino"],
    releaseDate: "1972-03-24",
  },
  {
    _id: "7",
    title: "Forrest Gump",
    poster:
      "https://m.media-amazon.com/images/M/MV5BNWIwODRlZTUtY2U3ZS00Yzg1LWJhNzYtMmZiYmEyNmU1NjMzXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg",
    genre: "Drama",
    year: 1994,
    duration: 142,
    rating: 8.8,
    price: 0.059,
    description: "The story of a man with low IQ who accomplishes great things.",
    director: "Robert Zemeckis",
    cast: ["Tom Hanks", "Robin Wright"],
    releaseDate: "1994-07-06",
  },
  {
    _id: "8",
    title: "The Shawshank Redemption",
    poster:
      "https://m.media-amazon.com/images/M/MV5BNDE3ODcxYzMtY2YzZC00NmNlLWJiNDMtZDViZWM2MzIxZDYwXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_SX300.jpg",
    genre: "Drama",
    year: 1994,
    duration: 142,
    rating: 9.3,
    price: 0.069,
    description: "Two imprisoned men bond over years, finding solace and redemption.",
    director: "Frank Darabont",
    cast: ["Tim Robbins", "Morgan Freeman"],
    releaseDate: "1994-09-23",
  },
]

async function tryFetchFromAPI() {
  // API endpoints from the OpenAPI spec
  const endpoints = [
    "https://pcpdfilm.starsknights.com:18888/api/v2/films",
    "http://pcpdfilm.starsknights.com/api/v2/films",
  ]

  for (const endpoint of endpoints) {
    try {
      console.log(`🎬 Attempting to connect to: ${endpoint}`)

      // Create an AbortController for timeout
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 8000) // 8 second timeout

      const response = await fetch(endpoint, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "User-Agent": "CinemaVault/1.0",
        },
        signal: controller.signal,
        cache: "no-cache",
        mode: "cors",
      })

      clearTimeout(timeoutId)

      if (response.ok) {
        const text = await response.text()

        if (!text || text.trim() === "") {
          console.log(`📭 Empty response from ${endpoint}`)
          continue
        }

        try {
          const movies = JSON.parse(text)

          // Validate that we got an array of movies
          if (Array.isArray(movies) && movies.length > 0) {
            console.log(`✅ Successfully fetched ${movies.length} movies from: ${endpoint}`)

            // Ensure all movies have poster images and adjust prices to 0.0x format
            const moviesWithPosters = movies.map((movie) => ({
              ...movie,
              poster: movie.poster || movie.image || movie.thumbnail || "/placeholder.svg?height=400&width=300",
              price: movie.price > 1 ? movie.price / 100 : movie.price, // Convert to 0.0x format if needed
            }))

            return { movies: moviesWithPosters, source: "api" }
          } else if (Array.isArray(movies) && movies.length === 0) {
            console.log(`📋 Empty movie list from ${endpoint}`)
            return { movies: [], source: "api" }
          } else {
            console.log(`❌ Invalid movie data structure from ${endpoint}`)
            continue
          }
        } catch (parseError) {
          console.log(`🔧 JSON parse error from ${endpoint}:`, parseError.message)
          continue
        }
      } else {
        console.log(`🚫 HTTP ${response.status} ${response.statusText} from ${endpoint}`)
        continue
      }
    } catch (error) {
      // Handle different types of errors silently
      if (error.name === "AbortError") {
        console.log(`⏰ Request timeout for ${endpoint}`)
      } else if (error.code === "ENOTFOUND" || error.code === "ECONNREFUSED") {
        console.log(`🌐 Network error for ${endpoint}: ${error.code}`)
      } else {
        console.log(`❌ Connection failed for ${endpoint}: ${error.message}`)
      }
      continue
    }
  }

  console.log("🎭 All API endpoints failed, using mock data")
  return { movies: mockMovies, source: "mock" }
}

export async function GET() {
  try {
    console.log("🎬 CinemaVault: Fetching movies from API...")

    // Try API first, but handle failures gracefully
    const result = await tryFetchFromAPI()

    // Add metadata to help the frontend understand the data source
    const response = {
      movies: result.movies,
      meta: {
        source: result.source,
        timestamp: new Date().toISOString(),
        total: result.movies.length,
      },
    }

    console.log(`📊 Returning ${result.movies.length} movies from ${result.source} source`)
    return NextResponse.json(response)
  } catch (error) {
    // Final fallback - this should never happen, but just in case
    console.error("💥 Unexpected error in movies API:", error)

    const fallbackResponse = {
      movies: mockMovies,
      meta: {
        source: "fallback",
        timestamp: new Date().toISOString(),
        total: mockMovies.length,
        error: "Unexpected error occurred",
      },
    }

    return NextResponse.json(fallbackResponse)
  }
}

export async function POST(request: Request) {
  try {
    const movieData = await request.json()
    const authHeader = request.headers.get("Authorization")
    const apiKey = request.headers.get("k")

    if (!authHeader && !apiKey) {
      return NextResponse.json({ error: "Authorization required" }, { status: 401 })
    }

    // Try to create movie using the API
    const endpoints = [
      "https://pcpdfilm.starsknights.com:18888/api/v2/film",
      "http://pcpdfilm.starsknights.com/api/v2/film",
    ]

    for (const endpoint of endpoints) {
      try {
        console.log(`📝 Attempting to create movie at: ${endpoint}`)

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 10000)

        const headers: Record<string, string> = {
          "Content-Type": "application/json",
          Accept: "application/json",
        }

        // Add authentication headers based on what's available
        if (apiKey) {
          headers["k"] = apiKey
        }
        if (authHeader) {
          headers["Authorization"] = authHeader
        }

        // Ensure poster field is included in the movie data and price is in 0.0x format
        const movieDataWithPoster = {
          ...movieData,
          poster: movieData.poster || movieData.image || movieData.thumbnail || "/placeholder.svg?height=400&width=300",
          price: movieData.price > 1 ? movieData.price / 100 : movieData.price, // Convert to 0.0x format if needed
        }

        const response = await fetch(endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify(movieDataWithPoster),
          signal: controller.signal,
        })

        clearTimeout(timeoutId)

        if (response.ok) {
          const text = await response.text()
          try {
            const result = JSON.parse(text)
            console.log(`✅ Successfully created movie at: ${endpoint}`)
            return NextResponse.json(result)
          } catch (parseError) {
            console.log(`🔧 Invalid JSON response from ${endpoint}:`, text)
            continue
          }
        } else {
          console.log(`🚫 HTTP ${response.status} from ${endpoint}`)
          continue
        }
      } catch (error) {
        console.log(`❌ Failed to create movie at ${endpoint}:`, error.message)
        continue
      }
    }

    // If all endpoints fail, return mock success response
    console.log("🎭 All POST endpoints failed, returning mock success")
    return NextResponse.json({
      success: true,
      id: Date.now().toString(),
      message: "Movie saved successfully (demo mode)",
      data: movieData,
    })
  } catch (error) {
    console.error("💥 Failed to save movie:", error)
    return NextResponse.json({ error: "Failed to save movie" }, { status: 500 })
  }
}
