import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const credentials = await request.json()

    // Try to authenticate using the API with Basic Auth
    const endpoints = [
      "https://pcpdfilm.starsknights.com:18888/api/v2/user",
      "http://pcpdfilm.starsknights.com/api/v2/user",
    ]

    for (const endpoint of endpoints) {
      try {
        console.log(`🔐 Attempting authentication at: ${endpoint}`)

        // Create Basic Auth header
        const basicAuth = btoa(`${credentials.username}:${credentials.password}`)

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 8000)

        const response = await fetch(endpoint, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Basic ${basicAuth}`,
          },
          signal: controller.signal,
        })

        clearTimeout(timeoutId)

        if (response.ok) {
          const text = await response.text()
          try {
            const userData = JSON.parse(text)
            console.log(`✅ Successfully authenticated at: ${endpoint}`)

            // Return successful authentication with API key
            return NextResponse.json({
              token: userData.k || `api-token-${Date.now()}`, // Use API key from response
              user: {
                type: "staff",
                username: credentials.username,
                ...userData,
              },
              source: "api",
            })
          } catch (parseError) {
            console.log(`🔧 Invalid JSON from ${endpoint}:`, parseError.message)
            continue
          }
        } else if (response.status === 401) {
          console.log(`🚫 Invalid credentials for ${endpoint}`)
          continue
        } else {
          console.log(`🚫 HTTP ${response.status} from ${endpoint}`)
          continue
        }
      } catch (error) {
        if (error.name === "AbortError") {
          console.log(`⏰ Authentication timeout for ${endpoint}`)
        } else {
          console.log(`❌ Authentication failed for ${endpoint}: ${error.message}`)
        }
        continue
      }
    }

    // If API authentication fails, try mock authentication
    console.log("🎭 API authentication failed, trying mock authentication")

    // Mock successful authentication for demo staff user
    if (credentials.username === "s235776767" && credentials.password === "1234567890") {
      return NextResponse.json({
        token: "mock-jwt-token-" + Date.now(),
        user: {
          type: "staff",
          username: credentials.username,
          firstName: "John",
          lastName: "Staff",
          email: "staff@cinemavault.com",
        },
        source: "mock",
      })
    }

    // Mock successful authentication for any wallet user
    if (credentials.type === "wallet") {
      return NextResponse.json({
        token: "mock-wallet-token-" + Date.now(),
        user: {
          type: "customer",
          wallet: true,
          address: credentials.address || "0x1234...5678",
        },
        source: "mock",
      })
    }

    // Authentication failed
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
  } catch (error) {
    console.error("💥 Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
