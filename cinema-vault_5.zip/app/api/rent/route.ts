import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { movieId, price } = await request.json()
    const authHeader = request.headers.get("Authorization")

    if (!authHeader) {
      return NextResponse.json({ error: "Authorization required" }, { status: 401 })
    }

    // Skip API call and use mock rental success
    console.log(`Using mock rental success for movie ID: ${movieId}`)
    return NextResponse.json({
      success: true,
      transactionId: "tx-" + Date.now(),
      message: "Movie rented successfully (demo mode)",
      movieId,
      price,
      rentalPeriod: "48 hours",
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
    })
  } catch (error) {
    console.error("Rental failed:", error)
    return NextResponse.json({ error: "Rental failed" }, { status: 500 })
  }
}
