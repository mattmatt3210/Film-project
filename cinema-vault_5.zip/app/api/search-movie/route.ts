import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const title = searchParams.get("title")
    const authHeader = request.headers.get("Authorization")
    const apiKey = request.headers.get("k")

    if (!title) {
      return NextResponse.json({ error: "Title parameter required" }, { status: 400 })
    }

    if (!authHeader && !apiKey) {
      return NextResponse.json({ error: "Authorization required" }, { status: 401 })
    }

    // Try to search using the OMDB API endpoint
    const endpoints = [
      `https://pcpdfilm.starsknights.com:18888/api/v2/ofilm/${encodeURIComponent(title)}`,
      `http://pcpdfilm.starsknights.com/api/v2/ofilm/${encodeURIComponent(title)}`,
    ]

    for (const endpoint of endpoints) {
      try {
        console.log(`🔍 Searching for "${title}" at: ${endpoint}`)

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 10000)

        const headers: Record<string, string> = {
          "Content-Type": "application/json",
          Accept: "application/json",
        }

        // Add authentication headers
        if (apiKey) {
          headers["k"] = apiKey
        }
        if (authHeader) {
          headers["Authorization"] = authHeader
        }

        const response = await fetch(endpoint, {
          headers,
          signal: controller.signal,
        })

        clearTimeout(timeoutId)

        if (response.ok) {
          const text = await response.text()
          try {
            const movieData = JSON.parse(text)
            console.log(`✅ Found movie "${title}" at: ${endpoint}`)

            // Ensure movie has a poster field and price is in 0.0x format
            const movieWithPoster = {
              ...movieData,
              poster:
                movieData.poster || movieData.image || movieData.thumbnail || "/placeholder.svg?height=400&width=300",
              price: movieData.price > 1 ? movieData.price / 100 : movieData.price, // Convert to 0.0x format if needed
            }

            return NextResponse.json({
              ...movieWithPoster,
              meta: {
                source: "api",
                timestamp: new Date().toISOString(),
              },
            })
          } catch (parseError) {
            console.log(`🔧 Invalid JSON from ${endpoint}:`, parseError.message)
            continue
          }
        } else if (response.status === 404) {
          console.log(`📭 Movie "${title}" not found at ${endpoint}`)
          continue
        } else {
          console.log(`🚫 HTTP ${response.status} from ${endpoint}`)
          continue
        }
      } catch (error) {
        if (error.name === "AbortError") {
          console.log(`⏰ Search timeout for ${endpoint}`)
        } else {
          console.log(`❌ Search failed for ${endpoint}: ${error.message}`)
        }
        continue
      }
    }

    // If API search fails, return mock data
    console.log(`🎭 API search failed, using mock data for "${title}"`)

    // Try to find a poster based on the title
    let posterUrl = "/placeholder.svg?height=400&width=300"

    // Simple mapping for common movie titles to posters
    const posterMap: Record<string, string> = {
      matrix:
        "https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg",
      inception: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg",
      interstellar:
        "https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
      "dark knight":
        "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_SX300.jpg",
      "pulp fiction":
        "https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTUtNTBlZi00MTRlLWFjM2ItYzViMjE3YzI5MjljXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",
      godfather:
        "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",
      "forrest gump":
        "https://m.media-amazon.com/images/M/MV5BNWIwODRlZTUtY2U3ZS00Yzg1LWJhNzYtMmZiYmEyNmU1NjMzXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg",
      "shawshank redemption":
        "https://m.media-amazon.com/images/M/MV5BNDE3ODcxYzMtY2YzZC00NmNlLWJiNDMtZDViZWM2MzIxZDYwXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_SX300.jpg",
    }

    // Check if the title matches any known movie
    const lowerTitle = title.toLowerCase()
    for (const key in posterMap) {
      if (lowerTitle.includes(key)) {
        posterUrl = posterMap[key]
        break
      }
    }

    const mockMovieData = {
      title: title,
      poster: posterUrl,
      genre: "Action",
      year: 2024,
      duration: 120,
      rating: 8.0,
      price: 0.059,
      description: `An exciting movie titled "${title}" that will keep you on the edge of your seat.`,
      director: "John Director",
      cast: ["Actor One", "Actor Two", "Actor Three"],
      releaseDate: "2024-01-01",
      meta: {
        source: "mock",
        timestamp: new Date().toISOString(),
      },
    }

    return NextResponse.json(mockMovieData)
  } catch (error) {
    console.error("💥 Search failed:", error)

    // Return mock data as fallback
    const title = new URL(request.url).searchParams.get("title") || "Unknown Movie"
    const mockMovieData = {
      title: title,
      poster: "/placeholder.svg?height=400&width=300",
      genre: "Action",
      year: 2024,
      duration: 120,
      rating: 8.0,
      price: 0.059,
      description: `An exciting movie titled "${title}" that will keep you on the edge of your seat.`,
      director: "John Director",
      cast: ["Actor One", "Actor Two", "Actor Three"],
      releaseDate: "2024-01-01",
      meta: {
        source: "fallback",
        timestamp: new Date().toISOString(),
      },
    }
    return NextResponse.json(mockMovieData)
  }
}
