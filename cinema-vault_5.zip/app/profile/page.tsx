"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Save, User, Calendar } from "lucide-react"

interface UserDetails {
  username: string
  email: string
  phone: string
  firstName: string
  lastName: string
  dateJoined: string
  lastLogin: string
}

export default function ProfilePage() {
  const router = useRouter()
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Check if user is authenticated
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/")
      return
    }
    setIsAuthenticated(true)
    fetchUserDetails()
  }, [router])

  const fetchUserDetails = async () => {
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/")
        return
      }

      const response = await fetch("/api/user/detail", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const data = await response.json()
      setUserDetails(data)
    } catch (error) {
      console.error("Error fetching user details:", error)
      // Mock data for demonstration
      setUserDetails({
        username: "s235776767",
        email: "staff@cinemavault.com",
        phone: "+1234567890",
        firstName: "John",
        lastName: "Staff",
        dateJoined: "2024-01-01",
        lastLogin: new Date().toISOString(),
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof UserDetails, value: string) => {
    if (!userDetails) return

    setUserDetails({
      ...userDetails,
      [field]: value,
    })
  }

  const saveUserDetails = async () => {
    if (!userDetails) return

    setSaving(true)
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/")
        return
      }

      const response = await fetch("/api/user", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(userDetails),
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      alert("Profile updated successfully!")
    } catch (error) {
      console.error("Save error:", error)
      alert("Error updating profile. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  if (!isAuthenticated || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  if (!userDetails) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-center">
          <h1 className="text-2xl font-bold mb-4">Failed to load profile</h1>
          <Button onClick={() => router.push("/")} variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <Button onClick={() => router.push("/")} variant="outline" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl text-white flex items-center">
              <User className="mr-2 h-6 w-6" />
              User Profile
            </CardTitle>
            <CardDescription className="text-gray-300">Manage your account information and preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-white">
                  Username (Read-only)
                </Label>
                <Input
                  id="username"
                  value={userDetails.username}
                  readOnly
                  className="bg-gray-600/50 border-white/20 text-gray-300"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={userDetails.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="firstName" className="text-white">
                  First Name
                </Label>
                <Input
                  id="firstName"
                  value={userDetails.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName" className="text-white">
                  Last Name
                </Label>
                <Input
                  id="lastName"
                  value={userDetails.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-white">
                  Phone Number
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={userDetails.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-white/20">
              <div className="space-y-2">
                <Label className="text-white flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  Date Joined
                </Label>
                <div className="text-gray-300 bg-gray-600/50 px-3 py-2 rounded-md">
                  {new Date(userDetails.dateJoined).toLocaleDateString()}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-white flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  Last Login
                </Label>
                <div className="text-gray-300 bg-gray-600/50 px-3 py-2 rounded-md">
                  {new Date(userDetails.lastLogin).toLocaleString()}
                </div>
              </div>
            </div>

            <div className="flex space-x-4 pt-6">
              <Button onClick={saveUserDetails} disabled={saving} className="bg-green-600 hover:bg-green-700">
                <Save className="mr-2 h-4 w-4" />
                {saving ? "Saving..." : "Save Changes"}
              </Button>
              <Button onClick={() => router.push("/")} variant="outline">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
